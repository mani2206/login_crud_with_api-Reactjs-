
const Dashboard = () => {
  return (
    <>
      <div className="home-banner">
        <h1><q>A LITTLE <span className='text-pink'>PROGRESS</span> EACH DAY ADDS UP TO <strong>BIG</strong> RESULTS</q></h1>
      </div>
    </>
  )
}

export default Dashboard;